
package br.com.ebooks.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class SevletController {
    @RequestMapping("/")
    public String inicio(){
        return "login";
    }
    
    @RequestMapping("/cadastrarProduto")
    public String cadastrarProduto(){
        return "cadastrarProduto";
    }
    
    @RequestMapping("/cadastrarFuncionario")
    public String cadastrarFuncionario(){
        return "cadastrarFuncionario";
    }
    
      @RequestMapping("/cadastrarFornecedor")
        public String cadastrarFornecedor(){
        return "cadastrarFornecedor";
    }
        
    @RequestMapping("/buscarProduto")
        public String buscarProduto(){
        return "buscarProduto";
    }
        
    @RequestMapping("/buscarFuncionario")
        public String buscarFuncionario(){
        return "buscarFuncionario";
    }
    
     @RequestMapping("/buscarFornecedor")
        public String buscarFornecedor(){
        return "buscarFornecedor";
    }
        
    @RequestMapping("/alterarProduto")
        public String alterarProduto(){
        return "alterarProduto";
    }
        
    @RequestMapping("/alterarFuncionario")
        public String alterarFuncionario(){
        return "alterarFuncionario";
    }
    
     @RequestMapping("/alterarFornecedor")
        public String alterarFornecedor(){
        return "alterarFornecedor";
    }
}
